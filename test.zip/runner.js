const Mocha = require('mocha');
const path = require('path');
const fs = require('fs');
var config = require('./config/config');
var scriptHelper = require('./utils/proHelper');
var mochHelper = require('./utils/mochaHelper')
var qTestHelper = require('./utils/qTestHelper')

global.getAllTestCases = qTestHelper.getTestDetails();

if (config.mochaFullTestFlag) {
    scriptHelper.getAllTestDirctories(config.webServicefold, config.testScriptsfold, function (err, data) {
        if (err) { throw err; }
        mochHelper.mochaRunTestCases(data, qTestHelper);
    });
} else {
    var testDir = ["Web-Services/MSA/empinfo/TestScripts"];
    mochHelper.mochaRunTestCases(testDir, qTestHelper);
}

// Instantiate a Mocha instance.


