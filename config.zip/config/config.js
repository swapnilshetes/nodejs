var config = {};
/**
 * This is common file to initialize all constants related to this project
 */
// Constants of folder name
config.apiURL = "https://msaindiaservices.azurewebsites.net/"
config.authorization = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IjEwODQ2NDEwMDc4ODYyODEwNzEzNiIsInUiOiI2MWNmY2NlMy04NWFlLTRkOTctOWJiOC1hYzg1ZTZiM2IyZDIiLCJlIjoyOTg2LCJhbSI6IlByYW5qYWwudW1kZWthckBiaXR3aXNlZ2xvYmFsLmNvbSIsInVuIjoicHJhbmphbHUiLCJhZSI6dHJ1ZSwibmJmIjoxNTY1MDk5MTU1LCJleHAiOjE1NjY0ODE1NTUsImlhdCI6MTU2NTA5OTE1NSwiaXNzIjoiQml0d2lzZU1zYUFkbWluIiwiYXVkIjoiQml0d2lzZU1zYUFwcCJ9.tnniSH6e50u5sYMQtFMLH8oK4JH-kgo8NcdjTAZj49YSRlBdO5OheIsfaU2lpSr-6fshEeDyXpsLsE0sbKlyoAKuPoOdCOFX3QZQmoE-hWAmU3xV0-8ZNpGh3lVlUGC5nEfRT5BNnlVpq5bKsa00j3mSe7m2YdSmW2WVJbVwFkZ6gYDueMeh0XsCPfqauXQ0DNB7CTu_8O2_Lhuy8PggZItGcYGWi4UtM-zqiGFwFNf7k7SgTBgt60arahgNTFMabNPJRmhFHdgSjivE7au9VN1aaHgPViT90mORzcyRf-cENkMxTsU5VbCyPnZYWdxtF-Y8r_1D34UpofS3x5fKKA"
config.testJsonFiles = "test_data.json"
config.webServicefold = 'Web-Services';
config.requestfold = 'Request';
config.responsefold = 'Response';
config.testScriptsfold = 'TestScripts';
config.testDatafold = 'TestData';


//Constant mocha settings
config.mochaFullTestFlag = true
config.repFileName ="Execution-Report"
config.repTitle="Execution-Report-Title"
config.repPageTitle="Execution-Report-Page-Title"
config.enable_code = false
config.exetime = 1160000
config.testTags = ''

//constant qTest
config.qTest = {};
config.qTest.uploadDetailsFlag = true
config.qTest.token ='c07b0ebe-74a1-43d4-a665-26ab434a6c9f'
config.qTest.qTestUrl ='bitsolution.qtestnet.com'
config.qTest.suitId= 95066
config.qTest.projectID='943'
config.qTest.abedentLogFile='apis-fail-log.txt'

//Constant Error
config.errormsg= {}
config.errormsg.testCaseFailLog = "Test case fail log is not updated. Please check..."
config.errormsg.testCaseLogError = "Test Case is not present"
config.errormsg.unlinkfileError = "File is not unlink"
config.errormsg.qTestMochFileUpdateErr = "qTest File error..."
//Constant notifications
config.notification= {}

//constant Fail logs column
config.failLogColumn={}
config.failLogColumn.date ="Date"
config.failLogColumn.suiteName ="Suite Name"
config.failLogColumn.testName ="Test Name"
config.failLogColumn.error ="Error"

// QTest updateTestResult 
config.qTestUpdateRs = {}
config.qTestUpdateRs.prefic = "testresult-"
config.qTestUpdateRs.extention = ".txt"
config.qTestUpdateRs.fileheaderType = "text/plain"
config.qTestUpdateRs.statusP = "pass"
config.qTestUpdateRs.statusF = "fail"
config.qTestUpdateRs.statusS = "skip"

// QTest getTestDetails 
config.qTestGetTD = {}
config.qTestGetTD.headerContentType = "application/json"

module.exports = config;