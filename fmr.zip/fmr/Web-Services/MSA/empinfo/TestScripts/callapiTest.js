var fs = require('fs');
var path = require('path');
var helper = require('bit_matic');
var expect = require('chai').expect;
const addContext = require('mochawesome/addContext.js');
var scriptHelper = require('../../../../utils/proHelper');
var config = require('../../../../config/config');

var isArray = require('isarray');
var EventEmitter = require('events').EventEmitter;

//var qTestHelper = require('../../../../utils/qTestHelper')
//var getAllTestCases = qTestHelper.getTestDetails();

var test_data_path = path.join(__dirname, '../TestData/test_data.json');
var test_data = fs.readFileSync(test_data_path, 'utf8');

//console.log("########################### JSON DATA FROM XLSX ##########################");
//scriptHelper.getJsonDataFromXlsx( path.join(__dirname,"../TestData/testdata.xlsx"), path.join(__dirname, "../TestData/sample.json"),"Sheet1")
//console.log("#####################################################");

//convert test data into json object
var test_data_obj = JSON.parse(test_data);
var test_data_TestCaseWise = test_data_obj.TestCase;
var testData, apiURL, response, reportID, request_metadata;

apiURL = "https://msaindiaservices.azurewebsites.net/"

describe(test_data_obj.TestSuite, function () {

  var eventEmitter = new EventEmitter();

  eventEmitter.on("testCaseData", function (testCaseData) {

    it("getValidationAsPerTestCaseWiseSendToTemplate", function (done) {

      if (testCaseData.template == 1) {
        getResponceCodeAndHealthCheck(this, testCaseData, done);
      } else if (testCaseData.template == 2) {
        checkDeviceIdValid(this, testCaseData, done);
      } else {
        template2_failure(this, testCaseData, done);
      }
      this._runnable.title = testCaseData.TestCaseName;
      console.log('test case passed: ' + testCaseData.TestCaseName);

    })

  });



  for (var eachTestData in test_data_TestCaseWise) {
    //console.log(eachTestData + " : " + test_data_TestCaseWise[eachTestData]);
    if (null != eachTestData) {
      eventEmitter.emit("testCaseData", test_data_TestCaseWise[eachTestData]);
    }
  }


  function getResponceCodeAndHealthCheck(object, testData, done) {
    // console.log("######## template1_success -START ##########")
    // console.log(testData.TestCaseName)
    // console.log(testData.statusCode)
    var deviceId = testData.deviceId
    var urll = apiURL + "api/register/getuserdetails?DeviceID=" + deviceId
    var method = testData.type
    var options = {
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IjEwODQ2NDEwMDc4ODYyODEwNzEzNiIsInUiOiI2MWNmY2NlMy04NWFlLTRkOTctOWJiOC1hYzg1ZTZiM2IyZDIiLCJlIjoyOTg2LCJhbSI6IlByYW5qYWwudW1kZWthckBiaXR3aXNlZ2xvYmFsLmNvbSIsInVuIjoiUHJhbmphbHUiLCJhZSI6dHJ1ZSwibmJmIjoxNTYzNDUxNTUzLCJleHAiOjE1NjQ4MzM5NTMsImlhdCI6MTU2MzQ1MTU1MywiaXNzIjoiQml0d2lzZU1zYUFkbWluIiwiYXVkIjoiQml0d2lzZU1zYUFwcCJ9.I5Om7WBZOxlJit62iqOUDj1VzH7k2GT7HTtLGNxBltbUS4p8no50epsOKXRK2hQWPv0E8rKBqQeDKxil9DSIRBfnc8MhybYy0TZfcR7GxvYQY0rnUiqjRTx4TZ4IPDZ804iGJV06t0ZmHw45cWz7VyNnjNq5_P68rdyEu5AfQIaGS8iKBFxizpKZS4Ua6gi20Mrmt49dmmLHTVsMPUr5FgLHXhmBwh0D2n76C6T8QdFV5e2dtRTLp9fUkA6u2bESyeLCL0yAtt5Kw4qn8MOk3BdevDu87DPBSK_2FhhqdACijb4e4BJo0IOy6J53n9RZwjQPUU08Lod0gcXnKsFO_Q',
        'Content-Type': 'application/json'
      }
    };
    var response = helper.callapi(method, urll, options);
    response.on("success", function (success) {
      setTimeout(function () {
        //console.log(object)
        if (200 != success.statusCode) {
          addContext(object, urll + " is down with status code : " + success.statusCode);
        }

        expect(success.statusCode).to.equal(testData.statusCode);
        addContext(object, "URL :" + urll);
        addContext(object, "Request Method  :" + method);
        addContext(object, "Status  :" + success.statusCode);
        done();
      });
    });
    // console.log("######## template1_success -END ##########")
  }

  function checkDeviceIdValid(object, testData, done) {
    // console.log("######## template1_success -START ##########")
    // console.log(testData.TestCaseName)
    // console.log(testData.statusCode)
    var deviceId = testData.deviceId
    var urll = apiURL + "api/register/getuserdetails?DeviceID=" + deviceId
    var method = testData.type
    var options = {
      headers: {
        'Authorization': 'Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1bmlxdWVfbmFtZSI6IjEwODQ2NDEwMDc4ODYyODEwNzEzNiIsInUiOiI2MWNmY2NlMy04NWFlLTRkOTctOWJiOC1hYzg1ZTZiM2IyZDIiLCJlIjoyOTg2LCJhbSI6IlByYW5qYWwudW1kZWthckBiaXR3aXNlZ2xvYmFsLmNvbSIsInVuIjoiUHJhbmphbHUiLCJhZSI6dHJ1ZSwibmJmIjoxNTYzNDUxNTUzLCJleHAiOjE1NjQ4MzM5NTMsImlhdCI6MTU2MzQ1MTU1MywiaXNzIjoiQml0d2lzZU1zYUFkbWluIiwiYXVkIjoiQml0d2lzZU1zYUFwcCJ9.I5Om7WBZOxlJit62iqOUDj1VzH7k2GT7HTtLGNxBltbUS4p8no50epsOKXRK2hQWPv0E8rKBqQeDKxil9DSIRBfnc8MhybYy0TZfcR7GxvYQY0rnUiqjRTx4TZ4IPDZ804iGJV06t0ZmHw45cWz7VyNnjNq5_P68rdyEu5AfQIaGS8iKBFxizpKZS4Ua6gi20Mrmt49dmmLHTVsMPUr5FgLHXhmBwh0D2n76C6T8QdFV5e2dtRTLp9fUkA6u2bESyeLCL0yAtt5Kw4qn8MOk3BdevDu87DPBSK_2FhhqdACijb4e4BJo0IOy6J53n9RZwjQPUU08Lod0gcXnKsFO_Q',
        'Content-Type': 'application/json'
      }
    };
    var response = helper.callapi(method, urll, options);
    response.on("success", function (success) {

      setTimeout(function () {
        //console.log(object)
        if (200 != success.statusCode) {
          addContext(object, urll + " is down with status code : " + success.statusCode);
        }
        addContext(object, "Information :" + JSON.parse(success.body).errorMessage[0].key + "( " + JSON.parse(success.body).errorMessage[0].value + ") -" + deviceId);
        addContext(object, "URL :" + urll);
        addContext(object, "Request Method  :" + method);
        addContext(object, "Status  :" + success.statusCode);
        expect(JSON.parse(success.body).isSuccess).to.equal(true);

        done();
      });
    });

    // console.log("######## template1_success -END ##########")
  }


});