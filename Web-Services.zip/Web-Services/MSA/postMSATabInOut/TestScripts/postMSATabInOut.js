var fs = require('fs');
var path = require('path');
var helper = require('bit_matic');
var expect = require('chai').expect;
const addContext = require('mochawesome/addContext.js');
var scriptHelper = require('../../../../utils/proHelper');
var config = require('../../../../config/config');

var EventEmitter = require('events').EventEmitter;

//var qTestHelper = require('../../../../utils/qTestHelper')
//var getAllTestCases = qTestHelper.getTestDetails();

var test_data_path = path.join(__dirname, '..' + path.sep + config.testDatafold + path.sep + config.testJsonFiles);
var test_data = fs.readFileSync(test_data_path, 'utf8');

//console.log("########################### JSON DATA FROM XLSX ##########################");
//scriptHelper.getJsonDataFromXlsx( path.join(__dirname,"../TestData/testdata.xlsx"), path.join(__dirname, "../TestData/sample.json"),"Sheet1")
//console.log("#####################################################");

//convert test data into json object
var test_data_obj = JSON.parse(test_data);
var test_data_TestCaseWise = test_data_obj.TestCase;
var testData, apiURL, response, reportID, request_metadata;

apiURL = config.apiURL

describe(test_data_obj.TestSuite, function () {

  var eventEmitter = new EventEmitter();

  /**
 * eventEmitter.on after eventEmmiter.emmit but we have to define before the emmit action
 * to trigger properly 
 *  
 */
  eventEmitter.on("testCaseData", function (testCaseData) {

    it("execute Bit Api Suite", function (done) {

      if (1 == testCaseData.template) {
        getResponseCodeAndHealthCheck(this, testCaseData, done);
      } else if (2 == testCaseData.template) {
        checkDeviceIdNotValid(this, testCaseData, done);
      } else if (3 == testCaseData.template) {
        checkResposeWithProperResult(this, testCaseData, done);
      } else if (4 == testCaseData.template) {
        checkResposeWithInvalidParamType(this, testCaseData, done);
      } else {
        console.log("Invalid Test validation template.");
      }
      this._runnable.title = testCaseData.TestCaseName;
      //console.log('test case passed: ' + testCaseData.TestCaseName);

    })

  });

  /**
   * For loop is a initial Step where we trigger events for each test case
   * 
   */

  for (var eachTestData in test_data_TestCaseWise) {
    //console.log(eachTestData + " : " + test_data_TestCaseWise[eachTestData]);
    if (null != eachTestData) {
      eventEmitter.emit("testCaseData", test_data_TestCaseWise[eachTestData]);
    }
  }


  function getResponseCodeAndHealthCheck(object, testData, done) {
    // console.log("######## template1_success -START ##########")
    // console.log(testData.TestCaseName)
    // console.log(testData.statusCode)
    var deviceId = testData.deviceId
    var urll = apiURL + "api/inout/request-inout"
    var method = testData.type
    var options = {
      headers: {
        'Authorization': config.authorization,
        'Content-Type': 'application/json'
      },
      json : testData.requestBody
    };
    var response = helper.callapi(method, urll, options);
    response.on("success", function (success) {
      setTimeout(function () {
        addContext(object, "URL :" + urll);
        addContext(object, "Request Method  :" + method);
        addContext(object, "Status  :" + success.statusCode);
        expect(success.statusCode).to.equal(testData.statusCode);
        done();
      });
    });
    // console.log("######## template1_success -END ##########")
  }

  function checkDeviceIdNotValid(object, testData, done) {
    // console.log("######## template1_success -START ##########")
    // console.log(testData.TestCaseName)
    // console.log(testData.statusCode)
    var deviceId = testData.deviceId
    var urll = apiURL + "api/inout/request-inout"
    var method = testData.type
    var options = {
      headers: {
        'Authorization': config.authorization,
        'Content-Type': 'application/json'
      },
      json : testData.requestBody
    };
    var response = helper.callapi(method, urll, options);
    response.on("success", function (success) {

      setTimeout(function () {
        addContext(object, "Information :" + JSON.parse(success.body).errorMessage[0].key + "( " + JSON.parse(success.body).errorMessage[0].value + ") -" + deviceId);
        addContext(object, "URL :" + urll);
        addContext(object, "Request Method  :" + method);
        addContext(object, "Status  :" + success.statusCode);
        expect(JSON.parse(success.body).errorMessage[0].key).to.equal("DEVICE_ID_CHANGED");

        done();
      });
    });

    // console.log("######## template1_success -END ##########")
  }

  function checkResposeWithProperResult(object, testData, done) {
    // console.log("######## template1_success -START ##########")
    // console.log(testData.TestCaseName)
    // console.log(testData.statusCode)
    var deviceId = testData.deviceId
    var urll = apiURL + "api/inout/request-inout"
    var method = testData.type
    var options = {
      headers: {
        'Authorization': config.authorization,
        'Content-Type': 'application/json'
      },
      json : testData.requestBody
    };
    var response = helper.callapi(method, urll, options);

    response.on("success", function (success) {
      //console.log(JSON.stringify(JSON.parse(success.body).results.avatar))
      setTimeout(function () {
        addContext(object, "URL :" + urll);
        addContext(object, "Request Method  :" + method);
        addContext(object, "Status  :" + success.statusCode);
        expect(JSON.stringify(JSON.parse(success.body).results)).to.contain("avatar")
          .contain("rootCheck")
          .contain("adminEmail")
          .contain("adminMobile")
          .contain("msaGmailID")
          .contain("msaGmailOAuth")
          .contain("displayName")
          .contain("userName")
          .contain("employeeId")
          ;

        expect(JSON.parse(success.body).results.employeeId).to.equal(2986);
        done();
      });
    });

    // console.log("######## template1_success -END ##########")
  }

  function checkResposeWithInvalidParamType(object, testData, done) {
    // console.log("######## template1_success -START ##########")
    // console.log(testData.TestCaseName)
    // console.log(testData.statusCode)
    var deviceId = testData.deviceId
    var urll = apiURL + "api/inout/request-inout"
    var method = testData.type
    var options = {
      headers: {
        'Authorization': config.authorization,
        'Content-Type': 'application/json'
      },
      json : testData.requestBody
    };
    //console.log(options)
    var response = helper.callapi(method, urll, options);
    

    response.on("success", function (success) {
      console.log(JSON.parse(success.body))
      setTimeout(function () {
        addContext(object, "URL :" + urll);
        addContext(object, "Request Method  :" + method);
        addContext(object, "Status  :" + success.statusCode);
        expect(JSON.parse(success.body).isSuccess).to.equal(false);
        done();
      });
    });

    // console.log("######## template1_success -END ##########")
  }
});