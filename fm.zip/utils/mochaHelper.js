const Mocha = require('mocha');
const fs = require('fs');
const path = require('path');
var config = require('../config/config');


module.exports  = {
    mochaRunTestCases :  function(testDir, qTestHelper) {
        var repFileName= "Execution-Report";
        var repTitle="Execution-Report-Title";
        var repPageTitle= "Execution-Report-Page-Title";
        var enable_code= false;
        var exetime= 1160000;

        if (testDir == null) return {"isSuccess" : false, "error" : "No scripts provided , hence unable to trigger scripts"};
        
            const mocha = new Mocha({
                reporter: 'mochawesome',
                reporterOptions: {
                        reportFilename: repFileName,
                        reportTitle: repTitle,
                        reportPageTitle:repPageTitle,
                        inlineAssets:true,
                        enableCode: enable_code,
                        quiet:true,
                        timestamp: 'ddmmyyyyHH:MM:ss'
                  },
                  
                timeout: 15000
            });

            for(i = 0; i<testDir.length; i++){
                // Add each .js file to the mocha instance
                var testDirPath = path.join('', testDir[i]);
                fs.readdirSync(testDirPath)
                    .filter(file => file.substr(-3) === '.js')
                    .forEach(file => mocha.addFile(
                             path.join(testDirPath, file)
                    ));
                    //mocha.addFile(path.join(testDirPath, 'parameterizationTest.js'));
                }

                mocha.run()
                .on('fail', function (test, err) {
                       //console.log('Test fail');
                       //console.log(err);
                })
                .on('end', function () {
                      for(var i=0; i<mocha.suite.suites.length ; i++) {
                            //console.log("### Mocha Suite Title ########")
                            // console.log(mocha.suite.suites[i].title)

                            // console.log("### Mocha Suite > test array inside each suite ########")
                            // console.log(mocha.suite.suites[i].tests)
                            for(var j=0; j<mocha.suite.suites[i].tests.length; j++) {
                                //console.log("### Mocha Suite > test title ########")
                                //console.log(mocha.suite.suites[i].tests[j].title)
                                var testDetails = getAllTestCases.find( testcasename => testcasename.name === mocha.suite.suites[i].tests[j].title) ;
                                if(undefined === testDetails) {
                                      module.exports.mochaRunTestCasesFailLog(mocha.suite.suites[i].title , mocha.suite.suites[i].tests[j].title)
                                } else {
                                    if(config.qTest.uploadDetailsFlag)
                                        qTestHelper.updateTestResult(testDetails , mocha.suite.suites[i].tests[j]);
                                }
                              
                            }
                            
                        }
                });

                
        return;
    },
    mochaRunTestCasesFailLog: function(suiteTitle, testName) {
        var attachmentPath = (process.cwd()) + "/";
        var abedentLogFile = attachmentPath + config.qTest.abedentLogFile;
        var ExecDate=new Date().toISOString().split("T")[0]
        try {
            if (fs.exists(abedentLogFile)) {
                fs.appendFile(abedentLogFile,"\r\n"+ ExecDate + "   |  " + suiteTitle + " | "  +testName+"   |    " +  config.errormsg.testCaseLogError + "\r\n", function(ferr) {
                   if(ferr) console.log(config.errormsg.testCaseFailLog) 
                });
            } else {
                fs.writeFile(abedentLogFile, config.failLogColumn.date + "   |   " + config.failLogColumn.suiteName +"   |   " + config.failLogColumn.testName +"   |   " +  config.failLogColumn.error + "\r\n", function(ferr) {
                    if(ferr) console.log(config.errormsg.testCaseFailLog)
                });
                fs.appendFile(abedentLogFile,"\r\n"+ ExecDate + "    |   " + suiteTitle + " | "  +testName+"   |    " +  config.errormsg.testCaseLogError + "\n\n\r", function(ferr) {
                    if(ferr) console.log(config.errormsg.testCaseFailLog)
                });
            }
          } catch(err) {
            console.error(err)
          }

    }

};
//exports.data = methods;