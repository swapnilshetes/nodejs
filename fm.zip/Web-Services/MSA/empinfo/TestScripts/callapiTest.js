var helper = require('bit_matic');
var expect = require('chai').expect;
const addContext = require('mochawesome/addContext.js');
//var qTestHelper = require('../../../../utils/qTestHelper')
//var getAllTestCases = qTestHelper.getTestDetails();

var healthcheck = function(contextObject, response, apiName, requestMethod){

  response.on("success", function(success){
    setTimeout(function(){
        expect(success.statusCode).to.equal(200);
        var output = JSON.parse(success.body.toString('utf8'));
        addContext(contextObject, apiName + " is down with status code : " + success.statusCode );
        addContext(contextObject, "URL :" + apiName );
        addContext(contextObject, "Method :" + requestMethod );
        done();
    });
  });

    
};

describe("BitAPI suite 1", function(){

  it('It should execute POST call when passed with correct response status code', function(done){
    //This test was written as PoA for Calling BQ APIs for executing Querries, which serves as testcase as well for POSt call :)
    //Need tp udpate key, project id (part of URL) and auth token before running this test case
    var options = {
    };
    var url = 'https://reqres.in/api/users?page=2';
    var method= 'GET'
    var response = helper.callapi('GET', url , options);
    console.log("#####inside test ###########")
    console.log(response)
    
    healthcheck(this,response, url , method)
    /*
      response.on("success", function(success){
        setTimeout(function(){
            expect(success.statusCode).to.equal(200);
            var output = JSON.parse(success.body.toString('utf8'));
            addContext(this, url + " is down with status code : " + success.statusCode );
            addContext(this, "URL :" + url );
            addContext(this, "Method :" + method );
            done();
        });
      });
    */
  });

  it('It should execute POST', function(done){
    //This test was written as PoA for Calling BQ APIs for executing Querries, which serves as testcase as well for POSt call :)
    //Need tp udpate key, project id (part of URL) and auth token before running this test case
    var url = 'https://reqres.in/api/users?page=2';
    var method= 'GET'

    var options = {
    headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ya29.GmNSBsAmdIfqGEOQn7rBUCWcvFkId6o_MVshy6oelYlI3tRhoti9x2TcqxqqGj-4_bt9naYf5Ov8xKAJjUCTL2UrJGLhfBD49gbbpNUeFelVssWyrhtBn779gYxe8wQiGEBAWO4'
    },
    'json': {'query': "SELECT email, merchant, epoch FROM consumption_layer.bv_data_access where email = 'merchant_account_admin@globalpay.com' limit 5"}
    };

    

      var response = helper.callapi(method,url, options);
      healthcheck(this, response, url , method)
      /*
          response.on("success", function(success){
            setTimeout(function(){
                expect(success.statusCode).to.equal(200);
                var output = JSON.parse(success.body.toString('utf8'));
                addContext(this, url + " is down with status code : " + success.statusCode );
                addContext(this, "URL :" + url );
                addContext(this, "Method :" + method );
                done();
            });
          });
      */
  });

});