var config = {};
/**
 * This is common file to initialize all constants related to this project
 */
// Constants of folder name
config.webServicefold = 'Web-Services';
config.requestfold = 'Request';
config.responsefold = 'Response';
config.testScriptsfold = 'TestScripts';
config.testDatafold = 'TestData';

//Constant mocha 
config.mochaFullTestFlag = true

//constant qTest
config.qTest = {};
config.qTest.uploadDetailsFlag = false
config.qTest.token ='0099ad40-0083-42c7-a29f-9262b0768490'
config.qTest.qTestUrl ='bitsolution.qtestnet.com'
config.qTest.suitId= 94322
config.qTest.projectID='1069'
config.qTest.abedentLogFile='apis-fail-log.txt'

//Constant Error
config.errormsg= {}
config.errormsg.testCaseFailLog = "Test case fail log is not updated. Please check..."
config.errormsg.testCaseLogError = "Test Case is not present"
config.errormsg.unlinkfileError = "File is not unlink"
config.errormsg.qTestMochFileUpdateErr = "qTest File error..."
//Constant notifications
config.notification= {}

//constant Fail logs column
config.failLogColumn={}
config.failLogColumn.date ="Date"
config.failLogColumn.suiteName ="Suite Name"
config.failLogColumn.testName ="Test Name"
config.failLogColumn.error ="Error"

// QTest updateTestResult 
config.qTestUpdateRs = {}
config.qTestUpdateRs.prefic = "tmp-"
config.qTestUpdateRs.extention = ".txt"
config.qTestUpdateRs.statusP = "pass"
config.qTestUpdateRs.statusF = "fail"
config.qTestUpdateRs.statusS = "skip"

// QTest getTestDetails 
config.qTestGetTD = {}
config.qTestGetTD.headerContentType = "application/json"

module.exports = config;