const Mocha = require('mocha');
const path = require('path');
const fs = require('fs');
var config = require('../config/config');
var scriptHelper = require('../utils/proHelper');
var mochHelper = require('../utils/mochaHelper')
var qTestHelper = require('../utils/qTestHelper')
// Instantiate a Mocha instance.

var repFileName= "new-Execution-Report";
var repTitle="Execution-Report-Title";
var repPageTitle= "Execution-Report-Page-Title";
var enable_code= false;
var exetime= 1160000;


const mocha = new Mocha({
    reporter: 'mochawesome',
    reporterOptions: {
            reportFilename: repFileName,
            reportTitle: repTitle,
            reportPageTitle:repPageTitle,
            enableCode: enable_code,
            quiet:true,
            enableCharts: false,
            autoOpen:true,
            timestamp: 'ddmmyyyyHH:MM:ss'
      }
});

var testDir =['../Web-Services/MSA/empinfo/TestScripts/'];

for(i = 0; i<testDir.length; i++){
// Add each .js file to the mocha instance
var testDirPath = path.join(__dirname, testDir[i]);
  fs.readdirSync(testDirPath)
     .filter(file => file.substr(-3) === '.js')
     .forEach(file => mocha.addFile(path.join(testDirPath, file)));
    //mocha.addFile(path.join(testDirPath, 'parameterizationTest.js'));
}

// Run the tests.
mocha.run(failures => {
  process.on('exit', () => {
    process.exit(failures);  // exit with non-zero status if there were failures
  });
});