var sync_request = require('sync-request')
var qhelper = require('bit_matic')
var fileSystem = require("fs");  // Variable to create result log file and delete
var config = require('../config/config');


/********* Variable Declaration ********/
var qTestTestCaseDetails = [];  // Array variable to collect all test details from qTest suite
var testAttributeName = '';  // variable to fetch Test attributes from qTest response
var testDetails = '';   // variable to fetch individual test attributes from qTestTestCaseDetails array
var Testname = '';
var attachmentPath = (process.cwd()) + "/";
var abedentLogFile = attachmentPath + config.qTest.abedentLogFile;



module.exports = {
    /*
     * #getTestDetails:- Function uses sync-request and collects all test cases details from specified test suite
     * Details required from qTest for each test case:- Test case ID, Test case name & Test case qTest object ID   
     */
    getTestDetails: function () {
        if (true) {
            var res = sync_request('GET', "https://" + config.qTest.qTestUrl + "/api/v3/projects/" + config.qTest.projectID + "/test-runs?parentId=" + config.qTest.suitId + "&parentType=test-suite",
                {
                    headers: {
                        'Content-Type': config.qTestGetTD.headerContentType,
                        'Authorization': 'bearer ' + config.qTest.token  // qTest Token is mandatory and it is user specific
                    },

                });

            /** 
             * Parse the response and fetch the test details such as id, name, pid etc... 
             * and put all test cases details in Array 'qTestTestCaseDetails' 
             * */
            var test = JSON.parse(res.getBody());

            for (testAttributeName in test) {
                var Item = {
                    "id": test[testAttributeName].id,
                    "name": test[testAttributeName].name,
                    "pid": test[testAttributeName].pid,
                }
                qTestTestCaseDetails.push(Item);

            }
        }
        //console.log("########## fetch testCase Object in  ##########")
        //console.log(qTestTestCaseDetails)
        /*console.log("########## fetch testCase Object ##########")
        qTestTestCaseDetails.push({ id: 'abc', name: 'testcase1', pid: '125' });
        qTestTestCaseDetails.push({ id: 'efg', name: 'testcase2', pid: '126' });
        qTestTestCaseDetails.push({ id: 'hij', name: 'testcase3', pid: '127' });
        qTestTestCaseDetails.push({ id: 'lmn', name: 'testcase4', pid: '128' });
        */
        return qTestTestCaseDetails;
    },

    /**
     * #updateTestResult:- Function uses async-request and update test status in qTest along with testlog attachement
     * @TestcaseName: Test case name as per qTest
     * @Status: PASS/FAIL/SKIP
     * @jsObject: JSON object which needs to convert in execution log of test case
     */

    updateTestResult: function (testDetails, mochaContext, mochaErr, mochaStatus) {

        // Fetch the details of specific 
        var testRunObjectId = testDetails.id
        var testRunid = testDetails.pid.split("-")[1]

        Testname = testDetails.name
        var attachmentName = config.qTestUpdateRs.prefic + testRunid + config.qTestUpdateRs.extention
        var status = "";
        if ("passed" == (mochaStatus))
            status = config.qTestUpdateRs.statusP
        else if ("failed" == (mochaStatus))
            status = config.qTestUpdateRs.statusF
        else
            status = config.qTestUpdateRs.statusS
        /*
        console.log("######### update ##########")
        console.log(testRunObjectId)
        console.log(testRunid)
        console.log(Testname)
        console.log(status)
        */

        var dataUpload = "";
        //****************************  Create File/ create base 64 data ******************************     
        //  if(null !=mochaContext )
        //      module.exports.qTestmochaFileWrite(attachmentName , "context : " + mochaContext );

        //  if(null !=mochaErr )
        //      module.exports.qTestmochaFileWrite(attachmentName , "error : " + mochaErr );    

        if (null != mochaContext)
            dataUpload = dataUpload + "\r\n context : " + mochaContext;

        if (null != mochaErr)
            dataUpload = dataUpload + "\r\n error : " + mochaErr;
        
        dataUpload = "State: " + status + "\r\n" + dataUpload;
        var dataUpload64Buff = new Buffer(dataUpload);
        var dataUpload64 = dataUpload64Buff.toString('base64');
        //************************************************************************/

        var url = "https://" + config.qTest.qTestUrl + "/api/v3/projects/" + config.qTest.projectID + "/test-runs/" + testRunObjectId + "/auto-test-logs";

        //------------ Request to update test result in qTest -------------------

        var opts = {
            headers: {
                'Content-Type': config.qTestGetTD.headerContentType,
                'Authorization': 'bearer ' + config.qTest.token
            },
            body: JSON.stringify({
                "id": testRunid,
                "exe_start_date": new Date().toISOString(),
                "exe_end_date": new Date().toISOString(),
                "note": "string",
                "attachments": [
                    {
                        "name": attachmentName,
                        "content_type": config.qTestUpdateRs.fileheaderType,
                        "data": dataUpload64,
                        "author": {}
                    }
                ],
                "name": Testname,
                "planned_exe_time": 0,
                "actual_exe_time": 0,
                "build_number": "string", //Jenkins jobs build number
                "build_url": "string", //Jenkins jobs build URL, example: http://localhost:8080/jenkins                
                "status": status // example: PASS, FAIL, SKIP                
            }),
        }

        var response = qhelper.callapi("POST", url, opts);
        response.on("success", function (success) {
            setTimeout(function () {
                var output = JSON.parse(success.body.toString('utf8'));
                //console.log(JSON.stringify(output, null, 2));
                /*fileSystem.unlink(attachmentName,function(ferr){
                    if(ferr) console.log(config.errormsg.unlinkfileError)
                })*/
            });
        });
    },
    qTestmochaFileWrite: function (attachmentName, contentMochaObject) {

        fileSystem.appendFile(attachmentName, (contentMochaObject) + '\r\n', function (ferr) {
            if (ferr) console.log(config.errormsg.qTestMochFileUpdateErr)
        });
        return;
    }

};
//exports.data = methods;