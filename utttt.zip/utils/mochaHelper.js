const Mocha = require('mocha');
const fs = require('fs');
const path = require('path');
var config = require('../config/config');


module.exports = {
    mochaRunTestCases: function (testDir, qTestHelper) {
        var repFileName = config.repFileName;
        var repTitle = config.repTitle;
        var repPageTitle = config.repPageTitle;
        var enable_code = config.enable_code;
        var exetime = config.exetime;
        var tags = config.testTags;
        if (testDir == null) return { "isSuccess": false, "error": "No scripts provided , hence unable to trigger scripts" };

        const mocha = new Mocha({
            reporter: 'mochawesome',
           
            reporterOptions: {
                reportFilename: repFileName,
                reportTitle: repTitle,
                reportPageTitle: repPageTitle,
                inlineAssets: true,
                enableCode: enable_code,
                quiet: true,
                launchReport: true,
                timestamp: 'ddmmyyyyHH:MM:ss'
            },

            timeout: 15000,
            
        });
      
        for (i = 0; i < testDir.length; i++) {
            // Add each .js file to the mocha instance
            var testDirPath = path.join('', testDir[i]);
            fs.readdirSync(testDirPath)
                .filter(file => file.substr(-3) === '.js')
                .forEach(file => mocha.addFile(
                    path.join(testDirPath, file)
                ));
            //mocha.addFile(path.join(testDirPath, 'parameterizationTest.js'));
        }

        mocha.run()
            .on('fail', function (test, err) {
                //console.log('Test fail');
                //console.log(err);
            })
            .on('end', function () {
                for (var i = 0; i < mocha.suite.suites.length; i++) {
                    //console.log("### Mocha Suite Title ########")
                    // console.log(mocha.suite.suites)

                    // console.log("### Mocha Suite > test array inside each suite ########")
                    //console.log(mocha.suite.suites[i].tests)
                    for (var j = 0; j < mocha.suite.suites[i].tests.length; j++) {
                        //console.log("### Mocha Suite > test title ########")
                        //console.log(mocha.suite.suites[i].tests[j])
                        //console.log(mocha.suite.suites[i].tests[j].title)
                        // console.log(getAllTestCases)
                        //console.log(testcasename.name)
                        var testDetails = getAllTestCases.find(testcasename => testcasename.name === mocha.suite.suites[i].tests[j].title);
                        if (undefined === testDetails) {
                            module.exports.mochaRunTestCasesFailLog(mocha.suite.suites[i].title, mocha.suite.suites[i].tests[j].title)
                        } else {
                            if (config.qTest.uploadDetailsFlag) {
                                var context = null;
                                var errcontext = null;
                                var statuscontext = null;
                                //console.log("###### All Test Data ######")
                                //console.log(mocha.suite.suites[i].tests[j])
                                if (mocha.suite.suites[i].tests[j].hasOwnProperty("context")) {
                                    context = JSON.stringify( mocha.suite.suites[i].tests[j].context).replace("[", " " ).replace("]", " " ).replace(",", "\r\n").replace(",", "\r\n");
                                }
                                if (mocha.suite.suites[i].tests[j].hasOwnProperty("err")) {
                                    errcontext = mocha.suite.suites[i].tests[j].err;
                                }
                                if (mocha.suite.suites[i].tests[j].hasOwnProperty("state")) {
                                    statuscontext = mocha.suite.suites[i].tests[j].state;
                                }
                                qTestHelper.updateTestResult(testDetails, context, errcontext, statuscontext);
                            }

                        }

                    }

                }
            });


        return;
    },
    mochaRunTestCasesFailLog: function (suiteTitle, testName) {
        var attachmentPath = (process.cwd()) + "/";
        var abedentLogFile = attachmentPath + config.qTest.abedentLogFile;
        var ExecDate = new Date().toISOString().split("T")[0]

        try {
            if (fs.existsSync(abedentLogFile)) {

                fs.appendFile(abedentLogFile, "\r\n" + ExecDate + "   |  " + suiteTitle + " | " + testName + "   |    " + config.errormsg.testCaseLogError + "\r\n", function (ferr) {
                    if (ferr) console.log(config.errormsg.testCaseFailLog)
                });
            } else {
                fs.writeFile(abedentLogFile, config.failLogColumn.date + "   |   " + config.failLogColumn.suiteName + "   |   " + config.failLogColumn.testName + "   |   " + config.failLogColumn.error + "\r\n", function (ferr) {
                    if (ferr) console.log(config.errormsg.testCaseFailLog)
                });
                fs.appendFile(abedentLogFile, "\r\n" + ExecDate + "    |   " + suiteTitle + " | " + testName + "   |    " + config.errormsg.testCaseLogError + "\r\n", function (ferr) {
                    if (ferr) console.log(config.errormsg.testCaseFailLog)
                });
            }
        } catch (err) {
            console.error(err)
        }

    }

};
//exports.data = methods;